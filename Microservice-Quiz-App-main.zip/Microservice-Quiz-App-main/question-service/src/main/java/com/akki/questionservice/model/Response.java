package com.akki.questionservice.model;

import lombok.Data;

@Data
public class Response {

    private Integer rId;
    private String response;

}
